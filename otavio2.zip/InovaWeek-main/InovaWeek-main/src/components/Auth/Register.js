import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { registerUser } from '../../utils/auth';

const Register = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleRegister = async () => {
    const data = await registerUser(email, password);

    if (data) {
      console.log('Sucesso! Cadastro realizado com sucesso.', data);
      alert('Usuário cadastrado!');
    } else {
      alert('Erro ao registrar usuário!');
    }
  };

  return (
    <div className="auth-container">
      <h2>Cadastre-se</h2>
      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      <input
        type="password"
        placeholder="Senha"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <button onClick={handleRegister}>Cadastrar</button>
      <p>
        <Link to="/">Login</Link>
      </p>
    </div>
  );
};

export default Register;
